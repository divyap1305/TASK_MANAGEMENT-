<?php
session_start();
header("Location: dashboard.php");
exit();
?> 